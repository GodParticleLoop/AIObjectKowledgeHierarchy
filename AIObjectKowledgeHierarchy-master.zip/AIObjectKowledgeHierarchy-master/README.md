# AIObjectKowledgeHierarchy
Class Reasoning(as Kahne  : Wadsworth, Logic and Philosopy);
Class InheritanceHierarchies( as Lanzerini: Nardi: Simi: Wiley, Inheritance Hierarchies in Knowledge Representation and CRWin);
Class STLreferenceInstructions(as Musser : Derge: Saini: Addison Wesley);
git remote add origin git@github.com:GodParticleLoop/AIObjectKowledgeHierarchy.git
git push -u origin master
